#include <minix/syslib.h>
#include <minix/drivers.h>
#include "i8254.h"
#include <unistd.h>

#define C1 261
#define C2 523
#define C3 1046
#define D1 293
#define D2 587
#define D3 1174
#define D1b 277
#define D2b 554
#define D3b 1108
#define E1 329
#define E2 659
#define E3 1318
#define E1b 311
#define E2b 622
#define E3b 1244
#define F1 349
#define F2 698
#define F3 1396
#define G1 391
#define G2 783
#define G3 1567
#define G1b 369
#define G2b 739
#define G3b 1479
#define A1 440
#define A2 880
#define A3 1760
#define A1b 415
#define A2b 830
#define A3b 1661
#define B1 493
#define B2 787
#define B3 1975
#define B1b 466
#define B2b 932
#define B3b 1864
#define P 30000

int speaker_ctrl(unsigned char on) {
 if(on == 0){
  if(sys_outb(SPEAKER_CTRL,0x00) != OK)
   return 1;
 } else {
  if(sys_outb(SPEAKER_CTRL,0x03) != OK)
   return 1;
  }
 return 0;
}

int speaker_test(unsigned long freq, unsigned long time) {

 int i=0;
 int notes[279] = 
{E3,E3,P,E3,P,C3,E3,P,G3,P,P,P,P,G1,P,P,P,P,
C3,P,P,G2,P,P,E2,P,P,A2,P,B2,B2b,A2,P,G2,E3,P,G3,A3,P,F3,G3,P,E3,P,C3,D3,B2,P,P,P,
C3,P,P,G2,P,P,E2,P,P,A2,P,B2,B2b,A2,P,G2,E3,P,G3,A3,P,F3,G3,P,E3,P,C3,D3,B2,P,P,P,
P,G3,G3b,F3,E3b,P,E3,P,A2,C3,P,A2,P,C3,D3,E3,
P,G3,G3b,F3,E3b,P,E3,P,P,C2,P,C2,C2,P,P,P,P,
P,G3,G3b,F3,E3b,P,E3,P,A2,C3,P,A2,P,C3,D3,P,E3,
P,E3b,P,P,D3,P,P,C3,P,P,P,P,P,P,P,P,
P,C3,C3,P,C3,P,C3,D3,P,E3,C3,P,A2,G2,P,P,P,
P,C3,C3,P,C3,P,C3,D3,P,E3,P,P,P,P,P,P,
P,C3,C3,P,C3,P,C3,D3,P,E3,C3,P,A2,G2,P,P,P,
P,E3,E3,P,E3,P,C3,E3,P,G3,P,P,G2,P,P,P,P,
P,E3,C3,P,G2,G2,P,A2,P,P,F3,F3,F3,P,P,P,
P,B2,P,A3,A3,A3,P,G3,F3,E3,P,P,P,P,P,P,
P,E3,C3,P,G2,G2,P,A2,P,P,F3,F3,F3,P,P,P,
P,B2,P,P,F3,F3,F3,P,E3,D3,C3,P,P,P,P,P};

 if(speaker_ctrl(1))
 {
  printf("Speaker_ctrl Failed!\n");
  return 1;
 }

 for(i=0; i<279; i++){
  timer_set_square(2,notes[i]);
  usleep(150000);
  timer_set_square(2,P);
  usleep(10000);
  }

 if(speaker_ctrl(0))
 {
  printf("Speaker_ctrl Failed!\n");
  return 1;
 }
 
 return 0;
}
